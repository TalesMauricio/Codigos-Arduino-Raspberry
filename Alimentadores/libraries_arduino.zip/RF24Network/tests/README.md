This directory contians advanced tests to help with WRITING the library.  To understand how
to USE the library, please see the examples directory.
